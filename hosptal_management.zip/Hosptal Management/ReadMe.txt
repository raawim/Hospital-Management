Title: Hosptal Management
Description: Hospital Management. The administrator can register new employees and give the required rights to them. Room allocation, medicine, prescriptions, payments, etc will be controlled through this.
More details: mail to bourgia@gmail.com
Web-site : http://bourgia.googlepages.com


The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
